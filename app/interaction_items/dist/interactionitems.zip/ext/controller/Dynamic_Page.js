sap.ui.define(["sap/m/MessageToast"],function(e){"use strict";return{Dynamic_Page:function(n){e.show("Custom handler invoked.")}}});
//# sourceMappingURL=Dynamic_Page.js.map